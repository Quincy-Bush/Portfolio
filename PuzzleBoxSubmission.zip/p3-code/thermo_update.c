#include "thermo.h"
#include <stdio.h>
#include <stdlib.h>
// bush0405@umn.edu




/*int set_temp_from_ports(temp_t *temp){
    // Uses the two global variables (ports) THERMO_SENSOR_PORT and
    // THERMO_STATUS_PORT to set the fields of `temp`
    short sensorVal=THERMO_SENSOR_PORT;
    unsigned char status= THERMO_STATUS_PORT;
    int mask=1;
    if(THERMO_SENSOR_PORT<0 || THERMO_SENSOR_PORT>28800){      // If THERMO_SENSOR_PORT is negative or above its maximum trusted value (associated with +45.0 degC),
        temp->tenths_degrees=0;
        temp->temp_mode=3;
        return 1;                                               // this function sets the tenths_degrees to 0 and the temp_mode to 3 for `temp` before returning 1
    }else{
        mask=1;
        int match= mask<<2;
        if(status & match ){ //if(bit 2){}
              temp->tenths_degrees=0;
             temp->temp_mode=3;
            return 1;      
       }else{
            //  Otherwise, converts the sensor value to deg C using shift operations 
            //temp calculations  
            sensorVal=sensorVal>>5;  // 2^5=32 so x>>5 to divide by 32
            sensorVal=sensorVal-450;//sensorVal= sensorVal-450;
            if((THERMO_SENSOR_PORT & 0b011111 )>=16){
                sensorVal++;   // binary 1
            }
           // sensorVal= sensorVal-45;  why?
            temp->temp_mode=1;
            temp->tenths_degrees=sensorVal;
        }
        mask=1<<5;        
        
        if(status & mask ){    //  Further converts to deg F if indicated from THERMO_STATUS_PORT
            int cel=sensorVal;
            short far=((cel*9)/5)+320;
            // off?
            sensorVal=far;

             temp->temp_mode=2;
             temp->tenths_degrees=sensorVal;
        }  
    }
    //. Sets the fields of `temp` to appropriate
    // values. `temp_mode` is 1 for Celsius, and 2 for Fahrenheit. Returns
    // 0 on success.
return 0;
}
*/
// This function DOES NOT modify any global variables
// but may access them.
//
// CONSTRAINTS: Uses only integer operations. No floating point
// operations are used as the target machine does not have a FPU. Does
// not use any math functions such as abs().




// int set_display_from_temp(temp_t temp, int *display){ //more i read the more I get confused
//     //unsigned char status= THERMO_STATUS_PORT;
//     int dis=0;
//     int zero=0b1111011;
//     int one=0b1001000;
//     int two=0b0111101;
//     int three=0b1101101;
//     int four=0b1001110;
//     int five=0b1100111;
//     int six=0b1110111;
//     int seven=0b1001001;
//     int eight=0b1111111;
//     int nine=0b1101111;
//     //int blank=0b0000000;
//     int neg=0b0000100;
//     int E=0b0110111;
//     int R=0b1011111;
//     int digits[]={zero,one,two,three,four,five,six,seven,eight,nine};
//   /* int match= 1<<2;
//     if(status & match ){
//     	    dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//             return 1;
    
//     }*/

//   /*  if(temp.tenths_degrees<-451 || temp.tenths_degrees>900){
//     	    dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//             return 1;
    
//     }*/ 
//     //doesnt work if implemented
//     if(temp.temp_mode==3){
//             dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//             return 1;
    
//     }
    
    
//    else if(temp.temp_mode==1){
//         if(temp.tenths_degrees<-450 || temp.tenths_degrees>450){
//             dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//             return 1;
//         }
        
//     }else if (temp.temp_mode==2){
//         if(temp.tenths_degrees<-490 || temp.tenths_degrees>1130){
//             dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//             return 1;
//         }
         
//     }else if(temp.temp_mode<1 ||temp.temp_mode>2){
//         dis= dis | E;
//             dis= dis<<7;
//             dis= dis | R;
//             dis= dis <<7;
//             dis= dis | R;
//             dis= dis<<7;
//             *display=dis;
//         return 1;

//     }
    
//         int mytemp=temp.tenths_degrees;
//         int negt=0;
//         if(mytemp<0){
//             mytemp=mytemp*-1;
//             negt=1;
//         }
//         int temp_tenths= mytemp%10;
//         mytemp=mytemp/10;
//         int temp_ones= mytemp %10;
//         mytemp=mytemp/10;
//         int temp_tens= mytemp %10;
//         mytemp=mytemp/10;
//         int temp_hunds= mytemp%10;

       
//  	/* if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<21;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<21;
//       			dis=dis | match;
//       			*display=dis;
//        		}      
//        */
      
       
//         if(negt){                                             //Start with an integer variable of 0 (all 0 bits).
            
//             if(temp_hunds==0){
//                 if(temp_tens==0){
                
//                 	if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<14;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<14;
//       			dis=dis | match;
//       			*display=dis;
//        		} 
                   

                    
//                     dis=dis| neg;
//                     dis=dis<<7;
//                     temp.tenths_degrees=-temp.tenths_degrees;

//                     int mask=digits[temp_ones];
//                     dis= dis | mask;
//                     dis= dis <<7;

//                     mask=digits[temp_tenths];
//                     dis= dis | mask;
// 		     *display=dis;
// 		     return 0;
		     
               
//                 }else if(temp_tens!=0){
//                 	if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis;
//        		} 
                    
//                         dis=dis| neg;
//                         dis=dis<<7;
//                         temp.tenths_degrees=-temp.tenths_degrees;

//                         int mask=digits[temp_tens];
//                         dis= dis| mask;
//                         dis=dis<<7;

//                         mask=digits[temp_ones];
//                         dis= dis | mask;
//                         dis= dis <<7;

//                         mask=digits[temp_tenths];
//                         dis= dis | mask;
//                         *display=dis;
//                         return 0;
//                 }

//             }else if (temp_hunds!=0){  //negetive and int mask=digits[temp_hunds]!=0; 
//          	if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis;
//        		} 
//          	int mask=digits[temp_hunds];
//          	dis=dis| neg;
//                 dis=dis<<7;
//                 dis=dis|mask;
//                 dis=dis<<7;
//                 mask=digits[temp_tens];
//                dis= dis | mask;
//                dis=dis<<7;

                    
                    
//                 mask=digits[temp_ones];
//                 dis= dis | mask;
//                 dis= dis <<7;

//                 mask=digits[temp_tenths];
//                 dis= dis | mask;
//                 *display=dis;
//                 return 0;
//          }
//          }else{         //not negetive    
//            if(temp_hunds==0){
//                 if(temp_tens==0){
//                 	if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<21;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<21;
//       			dis=dis | match;
//       			*display=dis;
//        		} 

//                     int mask=digits[temp_ones];
//                     dis= dis | mask;
//                     dis= dis <<7;

//                     mask=digits[temp_tenths];
//                     dis= dis | mask;
// 		    *display=dis;
// 		     return 0;
		     
               
//                 }else if(temp_tens!=0){
//                 	if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<14;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<14;
//       			dis=dis | match;
//       			*display=dis;
//        		} 
                    
             
//                        int mask=digits[temp_tens];
//                         dis= dis | mask;
//                         dis=dis<<7;

//                         mask=digits[temp_ones];
//                         dis= dis | mask;
//                         dis= dis <<7;

//                         mask=digits[temp_tenths];
//                         dis= dis | mask;
//                         *display=dis;
//                         return 0;

//                     }
//          	}else{
//          	      if(temp.temp_mode==1){
//       			int mask=1;
//       			int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis; 
      	
//        		}else if(temp.temp_mode==2){
// 		      	int mask=2;
// 		      	int match=mask<<7;
//       			dis=dis | match;
//       			*display=dis;
//        		} 

         
         
//          	 int mask=digits[temp_hunds];
         	
//                 dis=dis|mask;
//                 dis=dis<<7;
//                 mask=digits[temp_tens];
//                 dis= dis | mask;
//                 dis=dis<<7;

                    
                    
//                 mask=digits[temp_ones];
//                 dis= dis | mask;
//                 dis= dis <<7;

//                 mask=digits[temp_tenths];
//                 dis= dis | mask;
//                 *display=dis;
//                 return 0;

    
// 		}
    
   
//  } 
//  	//dis=dis|1<<28;
//  	//dis=dis|1<<29;
 
//  	//int mask=1<<5;        
        
//        /* if(status & mask ){
//    	    mask=1;
//             match= mask<<1;
            
//             sensorVal= sensorVal ^ match;
//          }else{
//            mask=1;
//            match=mask<<28;
//            sensorVal=sensorVal^ match */
   
//  return 0;
// }
// */

// // Alters the bits of integer pointed to by display to reflect the
// temperature in struct arg temp.  If temp has a temperature value
// that is below minimum or above maximum temperature allowable or if
// the temp_mode is not Celsius or Fahrenheit, sets the display to
// read "ERR" and returns 1. Otherwise, calculates each digit of the
// temperature and changes bits at display to show the temperature
// according to the pattern for each digit.  This function DOES NOT
// modify any global variables except if `display` points at one.
// 
// CONSTRAINTS: Uses only integer operations. No floating point
// operations are used as the target machine does not have a FPU. Does
// not use any math functions such as abs().

// Breaks temperature down into constituent parts

         // actual temp in tenths of degrees
              // 1 for celsius, 2 for fahrenheit, 3 for error



//  int thermo_update(){
    


//     temp_t tempsucc;
//     //int display;
    
    
//   int succt= set_temp_from_ports(&tempsucc);
//   if (succt>0){
//       return 1;
//   }
  
  
//   int succd= set_display_from_temp(tempsucc,&THERMO_DISPLAY_PORT); 
//   if(succd>0){
//    return 1;

//   }

//   return 0;
//  }
// Called to update the thermometer display.  Makes use of
// set_temp_from_ports() and set_display_from_temp() to access
// temperature sensor then set the display. Always sets the display
// even if the other functions returns an error. Returns 0 if both
// functions complete successfully and return 0. Returns 1 if either
// function or both return a non-zero values.
// 
// CONSTRAINT: Does not allocate any heap memory as malloc() is NOT
// available on the target microcontroller.  Uses stack and global
// memory only.
