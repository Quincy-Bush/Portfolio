/** CSci-4611 Assignment 1 Support Code
 * Assignment concept and support code by Prof. Daniel Keefe, 2023
 * Inspired by Camille Utterbeck's "Text Rain" installation, 2000+
 * Copyright Regents of the University of Minnesota
 * Please do not distribute beyond the CSci-4611 course
 */


import * as gfx from 'gophergfx'


/**
 * A collection of helper routines for working with images stored in ImageData objects.
 * Feel free to add additional routines (e.g., image filters) if you like.  (We did in
 * our implementation.)
 */
export class ImageUtils
{
    /**
     * Creates a new ImageData object of the specified width and height.  Every byte in the data array
     * will be be initialized to 0 (i.e., black completely transparent pixels).
     */
    public static createBlank(width: number, height: number): ImageData
    {
        const nBytes = width * height * 4;
        return new ImageData(new Uint8ClampedArray(nBytes), width, height);
    }


    /**
     * Checks the image variable to determine if has already been created, then checks to see if it has
     * the desired width and height.  If these checks pass, then the function returns the existing image.
     * If either check fails, then the function creates a new ImageData object of the desired width and
     * height and returns it.  In this case, the image will be initialized using ImageUtils.createBlank().  
     * @param image Can be null, undefined, or an existing image
     * @param width The desired width of the image
     * @param height The desired height of the image
     * @returns The current image if it matches the desired width and height or a new image that matches
     */
    public static createOrResizeIfNeeded(image: ImageData | undefined | null, width: number, height: number): ImageData
    {
        if (!(image instanceof ImageData) || image.width != width || image.height != height) {
            return this.createBlank(width, height);
        } else {
            return image;
        }
    }


    /**
     * Returns a new ImageData object that is a deep copy of the source image provided.  This includes copying
     * all of the pixel data from the source to the new image object.
     */
    public static clone(source: ImageData): ImageData
    {
        const copyOfPixelData = new Uint8ClampedArray(source.data);
        return new ImageData(copyOfPixelData, source.width, source.height);
    }


    /**
     * Copies the pixel data from the source image into the pixels of the destination image.
     * @param source An existing ImageData object that is the source for the pixel data.
     * @param dest An existing ImageData object that is the destination for the pixel data.
     */
    public static copyPixels(source: ImageData, dest: ImageData): void
    {
        for (let i=0; i<source.data.length; i++) {
            dest.data[i] = source.data[i];
        }
    }
   
    public static convertToGrayscale(source: ImageData, dest: ImageData): void
    {
       
        //=========================================================================
        //Part 2.1 Convert to Grayscale
        //Iterate through the pixels in the source image data
        //Calculate the grayscale value for each pixel
        //Set the corresponding pixel values (r,g,b,a) in the destination image data to the grayscale value
        //When this is complete, uncomment the corresponding line in RainingApp.ts  
        //Provide the appropriate parameters to that function to view the effect
        //=========================================================================
        for (let i=0; i<source.data.length; i+=4) {
           
           
            const gry = 0.2126 * (source.data[i]+0) + 0.7152 * (source.data[i]+1) + 0.0722 * (source.data[i]+2);
            //dest.data.set([gry,gry,gry,source.data[i+3]],i);
            dest.data[i]=gry;
            dest.data[i+1]=gry;
            dest.data[i+2]=gry;
            dest.data[i+3]=source.data[i+3];
           
           
        }
    }


    public static convertToGrayscaleInPlace(image: ImageData): void
    {
        return this.convertToGrayscale(image, image);
    }


    public static mirror(source: ImageData, dest: ImageData): void
    {
        //=========================================================================
        //Part 2.2 Mirror the Image
        //Iterate through the pixels in the source image data
        //Calculate the mirrored pixel location
        //Set the corresponding pixel values (r,g,b,a) in the destination image data to the mirrored value
        //When this is complete, uncomment the corresponding line in RainingApp.ts  
        //Provide the appropriate parameters to that function to view the effect
        //=========================================================================
        for (let row=0; row<source.height; row++) {
            for (let col=0; col<source.width; col++) {
                const destWidth= source.width;
                const destHeight=source.height;


                const finDest= 4*((row * source.width) + source.width-1-col);


                const startPoint=4*(row *source.width+col)
               
                dest.data[finDest]=source.data[startPoint];
                dest.data[finDest+1]=source.data[startPoint+1];
                dest.data[finDest+2]=source.data[startPoint+2];
                dest.data[finDest+3]=source.data[startPoint+3];


               
               
            }


         
       
    }
}
    public static threshold(source: ImageData, dest: ImageData, threshold: number): void
    {
    //=========================================================================
    //Part 2.3 Threshold the Image
    //Iterate through the pixels in the source image data
    //Check if the pixel's color channel value is greater than or equal to the threshold
    //Set the corresponding pixel values (r,g,b,a) in the destination image data to the appropriate value
    //based on the threshold result
    //When this is complete, uncomment the corresponding line in RainingApp.ts  
    //Provide the appropriate parameters to that function to view the effect
    //=========================================================================


    for (let row=0; row<source.height; row++) {
        for (let col=0; col<source.width; col++) {


            const pixLoc= 4*((row * source.width) + col);


            if (source.data[pixLoc]>threshold*255){
                dest.data[pixLoc]=255;
                dest.data[pixLoc+1]=255;
                dest.data[pixLoc+2]=255;
                dest.data[pixLoc+3]=source.data[pixLoc+3];
            }else{
                dest.data[pixLoc]=0;
                dest.data[pixLoc+1]=0;
                dest.data[pixLoc+2]=0;
                dest.data[pixLoc+3]=source.data[pixLoc+3];
            }
   


    //everything black or white depending on thershold level/num
        }  




    }
    }
     // --- Additional Helper Functions ---
     // You may find it useful to complete these to assist with some calculations of RainingApp.ts
   
    public static getRed(image: ImageData, col: number, row: number)
    {  
        const red=image.data[(row*image.width+col)*4 +0];
        return (red);
    }


    public static getGreen(image: ImageData, col: number, row: number)
    {
        return image.data[col*4 +row*(image.width*4) +1];
    }


    public static getBlue(image: ImageData, col: number, row: number)
    {
        return image.data[col*4 +row*(image.width*4) +2];
    }


    public static getAlpha(image: ImageData, col: number, row: number)
    {
        return image.data[col*4 +row*(image.width*4) +3];
    }
}



